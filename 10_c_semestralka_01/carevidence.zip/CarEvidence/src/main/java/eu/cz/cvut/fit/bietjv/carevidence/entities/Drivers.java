/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package eu.cz.cvut.fit.bietjv.carevidence.entities;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author pavlijo5
 */
public class Drivers {
    private List<Driver> drivers = new ArrayList();

    public List<Driver> getDrivers() {
        return drivers;
    }

    public void setDrivers(List<Driver> drivers) {
        this.drivers = drivers;
    }
    
    

   
    
}
