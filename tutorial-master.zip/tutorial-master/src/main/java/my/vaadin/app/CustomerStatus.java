package my.vaadin.app;

public enum CustomerStatus {
    ImportedLead, NotContacted, Contacted, Customer, ClosedLost
}