package cz.cvut.fit.tjv.employeeis.rest_client;

import cz.cvut.fit.tjv.employeeis.dto.EmployeeDTO;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;

/**
 * Klientsky kod k RESTful webove sluzbe pro entitu Employee.
 * @author guthondr
 */
public class EmployeeClient {
    public static final String WEBSERVICE_URL = "http://localhost:8080/EmployeeIS/emps/employee";
    private Client client = ClientBuilder.newClient();
    private WebTarget clientTarget = client.target(WEBSERVICE_URL);
    
    public void delete(long id) {
        clientTarget.path("" + id).request().delete();
    }
    
    public void createOrUpdate(EmployeeDTO e) {
        clientTarget.request().put(Entity.entity(e, MediaType.APPLICATION_XML));
    }
    
    public Collection<EmployeeDTO> retrieveAll() {
        EmployeeDTO[] ret = clientTarget.request(MediaType.APPLICATION_XML).get(EmployeeDTO[].class);
        List<EmployeeDTO> result = Arrays.asList(ret);
        return result;
    }
}
