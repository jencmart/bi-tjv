package cz.cvut.fit.tjv.employeeis.rest_client;

import cz.cvut.fit.tjv.employeeis.dto.DepartmentDTO;
import cz.cvut.fit.tjv.employeeis.dto.EmployeeDTO;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;

/**
 * Klientsky kod k RESTful webove sluzbe pro entitu Employee.
 * @author guthondr
 */
public class DepartmentClient {
    public static final String WEBSERVICE_URL = "http://localhost:8080/EmployeeIS/emps/dept";
    private Client client = ClientBuilder.newClient();
    private WebTarget departmentTarget = client.target(WEBSERVICE_URL);
    
    public void delete(String site, String title) {
        departmentTarget.path(site + '-' + title).request().delete();
    }
    
    public void createOrUpdate(DepartmentDTO d) {
        departmentTarget.request().put(Entity.entity(d, MediaType.APPLICATION_XML));
    }
    
    public Collection<DepartmentDTO> retrieveAll() {
        DepartmentDTO[] ret = departmentTarget.request(MediaType.APPLICATION_XML).get(DepartmentDTO[].class);
        List<DepartmentDTO> result = Arrays.asList(ret);
        return result;
    }
}
