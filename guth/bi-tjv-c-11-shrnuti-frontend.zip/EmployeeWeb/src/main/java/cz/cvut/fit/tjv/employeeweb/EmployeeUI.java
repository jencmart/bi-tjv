package cz.cvut.fit.tjv.employeeweb;

import javax.servlet.annotation.WebServlet;

import com.vaadin.annotations.Theme;
import com.vaadin.annotations.VaadinServletConfiguration;
import com.vaadin.data.ValueProvider;
import com.vaadin.server.VaadinRequest;
import com.vaadin.server.VaadinServlet;
import com.vaadin.ui.Button;
import com.vaadin.ui.Grid;
import com.vaadin.ui.HorizontalLayout;
import com.vaadin.ui.Label;
import com.vaadin.ui.Layout;
import com.vaadin.ui.TextField;
import com.vaadin.ui.UI;
import com.vaadin.ui.VerticalLayout;
import com.vaadin.ui.components.grid.EditorSaveEvent;
import com.vaadin.ui.components.grid.EditorSaveListener;
import cz.cvut.fit.tjv.employeeis.dto.DepartmentDTO;
import cz.cvut.fit.tjv.employeeis.dto.EmployeeDTO;
import cz.cvut.fit.tjv.employeeis.rest_client.DepartmentClient;
import cz.cvut.fit.tjv.employeeis.rest_client.EmployeeClient;
import java.util.Optional;

/**
 * This UI is the application entry point. A UI may either represent a browser
 * window (or tab) or some part of an HTML page where a Vaadin application is
 * embedded.
 * <p>
 * The UI is initialized using {@link #init(VaadinRequest)}. This method is
 * intended to be overridden to add component to the user interface and
 * initialize non-component functionality.
 */
@Theme("mytheme")
public class EmployeeUI extends UI {

    /**
     * RESTful klient k entite Employee
     */
    private EmployeeClient empClient = new EmployeeClient();

    /**
     * RESTful klient k entite Department
     */
    private DepartmentClient deptClient = new DepartmentClient();
    
    /**
     * UI tabulka oddeleni
     */
    private Grid<DepartmentDTO> deptsTable = new Grid<>(DepartmentDTO.class);

    /**
     * (Znovu)nacteni tabulky se zamestnanci
     */
    private void loadEmployees(Grid<EmployeeDTO> empsTable) {
        empsTable.setItems(empClient.retrieveAll());
    }

    /**
     * Inicializace casti UI pro vypis a zadavani zamestnancu
     */
    private void initEmployees(Layout layout) {
        Label empsHeader = new Label("Employees");

        Grid<EmployeeDTO> empsTable = new Grid<>();
        empsTable.getEditor().setEnabled(true);
        empsTable.getEditor().addSaveListener(new EditorSaveListener<EmployeeDTO>() {
            @Override
            public void onEditorSave(EditorSaveEvent<EmployeeDTO> event) {
                empClient.createOrUpdate(event.getBean());
            }
        });
        empsTable.addColumn(EmployeeDTO::getId);
        empsTable.addColumn(EmployeeDTO::getName).setEditorComponent(new TextField(), EmployeeDTO::setName).setEditable(true);
        empsTable.addColumn(new ValueProvider<EmployeeDTO, String>() {
            @Override
            public String apply(EmployeeDTO s) {
                return s.getDepartment().getSite();
            }
        });
        empsTable.addColumn(new ValueProvider<EmployeeDTO, String>() {
            @Override
            public String apply(EmployeeDTO s) {
                return s.getDepartment().getTitle();
            }
        });
        empsTable.addComponentColumn(new ValueProvider<EmployeeDTO, Button>() {
            @Override
            public Button apply(EmployeeDTO source) {
                Button b = new Button("Delete");
                b.addClickListener(new Button.ClickListener() {
                    @Override
                    public void buttonClick(Button.ClickEvent event) {
                        empClient.delete(source.getId());
                        loadEmployees(empsTable);
                    }
                });
                return b;
            }
        });
        loadEmployees(empsTable);

        TextField name = new TextField("Name");
        Button submitNew = new Button("Add new employee");
        submitNew.addClickListener(new Button.ClickListener() {
            @Override
            public void buttonClick(Button.ClickEvent event) {
                Optional<DepartmentDTO> dept = deptsTable.getSelectionModel().getFirstSelectedItem();
                if (dept.isPresent()) {
                    DepartmentDTO d = dept.get();
                    EmployeeDTO e = new EmployeeDTO();
                    e.setDepartment(d);
                    e.setName(name.getValue());
                    empClient.createOrUpdate(e);
                    loadEmployees(empsTable);
                }
            }
        });

        layout.addComponents(empsHeader, empsTable, name, submitNew);
    }
    
    /**
     * Nacteni tabulky oddeleni pres RESTful webovou sluzbu
     */
    private void loadDepartments(Grid<DepartmentDTO> deptsTable) {
        deptsTable.setItems(deptClient.retrieveAll());
    }

    /**
     * Inicializace casti UI venovane oddelenim.
     */
    private void initDepartments(Layout layout) {
        Label deptsHeader = new Label("Departments");

        loadDepartments(deptsTable);

        TextField site = new TextField("Name");
        TextField title = new TextField("Title");
        Button submitNew = new Button("Add new department");
        submitNew.addClickListener(new Button.ClickListener() {
            @Override
            public void buttonClick(Button.ClickEvent event) {
                DepartmentDTO newDept = new DepartmentDTO();
                newDept.setSite(site.getValue());
                newDept.setTitle(title.getValue());
                deptClient.createOrUpdate(newDept);
                loadDepartments(deptsTable);
            }
        });

        layout.addComponents(deptsHeader, deptsTable, site, title, submitNew);
    }

    @Override
    protected void init(VaadinRequest vaadinRequest) {
        VerticalLayout layoutEmps = new VerticalLayout();
        initEmployees(layoutEmps);

        VerticalLayout layoutDepts = new VerticalLayout();
        initDepartments(layoutDepts);

        HorizontalLayout layout = new HorizontalLayout(layoutDepts, layoutEmps);
        setContent(layout);
    }

    @WebServlet(urlPatterns = "/*", name = "EmployeeUIServlet", asyncSupported = true)
    @VaadinServletConfiguration(ui = EmployeeUI.class, productionMode = false)
    public static class EmployeeUIServlet extends VaadinServlet {
    }
}
