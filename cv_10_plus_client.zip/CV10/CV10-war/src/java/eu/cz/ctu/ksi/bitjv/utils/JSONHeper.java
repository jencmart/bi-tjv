/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package eu.cz.ctu.ksi.bitjv.utils;

import eu.cz.ctu.ksi.bitjv.entities.Pizza;
import java.util.List;

/**
 *
 * @author pavlijo5
 */
public class JSONHeper {
    /*
    public static JSONObject getJsonFromMyFormObject(List<Pizza> Pizza)
  {
    JSONObject responseDetailsJson = new JSONObject();
    JSONArray jsonArray = new JSONArray();

    for (int i = 0; i < form.size(); i++)
    {
      JSONObject formDetailsJson = new JSONObject();
      formDetailsJson.put("form_id", form.get(i).getId());
      formDetailsJson.put("form_name", form.get(i).getName());

      jsonArray.add(formDetailsJson);
    }
    responseDetailsJson.put("forms", jsonArray);
    return responseDetailsJson;
  }
*/
}
