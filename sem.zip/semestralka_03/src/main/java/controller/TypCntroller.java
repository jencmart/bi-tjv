/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import entity.Prispevek;
import entity.Typ;
import java.math.BigDecimal;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

/**
 *
 * @author jencmart
 */
@Stateless
public class TypCntroller {

   @PersistenceContext
    private EntityManager em;

    public void create(Typ entity) {
        this.em.merge(entity);
    }

    public void remove( BigDecimal id) {
     Typ t = this.find(id);
        if(t != null)
            this.em.remove(t);     
    }

    public Typ find(BigDecimal id) {
        return this.em.find(Typ.class, id);
    }

    public List<Typ> findAll() {
         return this.em.createNativeQuery("SELECT * FROM TYP", Typ.class).getResultList();
    }
   
}
