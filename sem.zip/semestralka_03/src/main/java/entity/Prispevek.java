/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entity;

import java.io.Serializable;
import java.math.BigDecimal;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author jencmart
 */
@Entity
@Table(name = "PRISPEVEK")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Prispevek.findAll", query = "SELECT p FROM Prispevek p")
    , @NamedQuery(name = "Prispevek.findByPrispevekId", query = "SELECT p FROM Prispevek p WHERE p.prispevekId = :prispevekId")
    , @NamedQuery(name = "Prispevek.findByNadpis", query = "SELECT p FROM Prispevek p WHERE p.nadpis = :nadpis")
    , @NamedQuery(name = "Prispevek.findByTelo", query = "SELECT p FROM Prispevek p WHERE p.telo = :telo")})
public class Prispevek implements Serializable {

    
    private static final long serialVersionUID = 1L;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    
    @Basic(optional = false)
    @NotNull
    @Column(name = "PRISPEVEK_ID")
    private BigDecimal prispevekId;
    @Size(max = 50)
    @Column(name = "NADPIS")
    private String nadpis;
    @Size(max = 500)
    @Column(name = "TELO")
    private String telo;
    @JoinColumn(name = "UZIVATEL_ID", referencedColumnName = "UZIVATEL_ID")
    @ManyToOne(optional = false, fetch = FetchType.LAZY)
    private Uzivatel uzivatelId;

    public Prispevek() {
    }

    public Prispevek(BigDecimal prispevekId) {
        this.prispevekId = prispevekId;
    }

    public BigDecimal getPrispevekId() {
        return prispevekId;
    }

    public void setPrispevekId(BigDecimal prispevekId) {
        this.prispevekId = prispevekId;
    }

    public String getNadpis() {
        return nadpis;
    }

    public void setNadpis(String nadpis) {
        this.nadpis = nadpis;
    }

    public String getTelo() {
        return telo;
    }

    public void setTelo(String telo) {
        this.telo = telo;
    }

    public Uzivatel getUzivatelId() {
        return uzivatelId;
    }

    public void setUzivatelId(Uzivatel uzivatelId) {
        this.uzivatelId = uzivatelId;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (prispevekId != null ? prispevekId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Prispevek)) {
            return false;
        }
        Prispevek other = (Prispevek) object;
        if ((this.prispevekId == null && other.prispevekId != null) || (this.prispevekId != null && !this.prispevekId.equals(other.prispevekId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entity.Prispevek[ prispevekId=" + prispevekId + " ]";
    }
    
}
